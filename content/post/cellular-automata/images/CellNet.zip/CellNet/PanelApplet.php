<html>
	<head>
		<title>
			Cellular Automata Package
		</title>
		<link type="text/css" rel="stylesheet" href="../../style1.css">
	</head>
	<body>
		<?php include("../../ProgramMenu.htm"); ?>
		<div class="title">
			<h1>
				Cellular Automata Package
			</h1>
		</div>
		<p class="applet">
			<applet code="PanelApplet.class" width=700 height=700></applet>
		</p>
		<div class="box">
			<p class="text">
				Alright, so maybe I need to work on my user friendliness in my programs. Sue me.
				Ah lets see, the program starts up with a board full of blank cells. In order for
				something interesting to happen, you need to fill it up with either brain cells or
				life cells. Thats what the <B>Brain</B> and <B>Life</B> buttons do.
			</p>
			<p class="text">
				In the upper right hand corner of the screen, there is a textfield with a number
				below it. The number indicates how many generations are computed before redisplaying
				the board. It starts out at one, but increasing this number allows the simulation to go
				faster so that one can see what the board will look like in advanced stages. Putting an integer
				in the textfield and pressing enter will change this number.
			</p>
			<p class="text">
				Below that is a number, and a <B>Reset</B> button. This number simply shows what generation the
				simulation is on. Reset resets it back to 0.
			</p>
			<p class="text">
				The <B>Step</B> button steps the simulation forward a number of generations as indicated
				in the upper right hand corner, and redisplays the board. The <B>Pause</B> button toggles on
				and off the automatic stepping. The textfield next to that is a speed field for how fast the
				automatic stepping goes. Basically 20 for fast and 200 more for slow.
			</p>
			<p class="text">
				<B>Rand</B> Randomizes the cells firing states. <B>Clear</B> clears the cells firing states. <B>Act1</B>
				and <B>Act2</B> do nothing yet, but they will be used in future versions of the program.
			</p>
			<p class="text">
				Finally, the <B>Add</B> Button. Clicking on the board itself will either change what type of cell
				appears in that spot, or it will change the state of that spot. Clicking the add button determines
				what happens when you click the board.
			</p>
			<p class="text">
				Note, both Life and Brain cells have three states. I'm not going over the rules for the simulations now
				other than to say that life normally only has two states on and off. I've added a red state, for
				diseased. A diseased cell behaves exactly like it was a normal cell. If any firing cell comes into
				contact with a diseased cell, it becomes diseased.
			</p>
			<p class="text">
				Here, do this. Start the program, and click the life button. now click the rand button. Click the step
				button twice (to get rid of mass amounts of first gen cells). Make sure the add type is on state change.
				Double click on a few cells on the board (to set the state to red, or diseased.) Now click pause, and
				watch as the disease spreads.
			</p>
		</div>
	</body>
</html>
