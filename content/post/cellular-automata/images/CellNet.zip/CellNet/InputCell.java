//Shawn O'Neil
//Do what you want with my code, as long as my name stays on it.
import java.awt.*;
import java.awt.event.*;

public class InputCell extends Cell
	{

	public InputCell()
		{
		super();
		super.setBackgroundColor(Color.green);
		}

	public InputCell(boolean fire)
		{
		super(fire);
		super.setBackgroundColor(Color.green);
		}

	public void setCurrentState()
		{
		}
	}