//Shawn O'Neil
//Do what you want with my code, as long as my name stays on it.
import java.awt.*;
import java.awt.event.*;

public class Expected extends Cell
	{

	public Expected()
		{
		super();
		super.setBackgroundColor(Color.orange);
		}

	public Expected(boolean fire)
		{
		super(fire);
		super.setBackgroundColor(Color.orange);
		}
	}