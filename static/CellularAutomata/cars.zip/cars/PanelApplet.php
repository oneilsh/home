<html>
	<head>
		<title>
			Cars
		</title>
		<link type="text/css" rel="stylesheet" href="../../style1.css">
	</head>
	
	<body>
		<?php include("../../ProgramMenu.htm"); ?>
		<div class="title">
			<h1>
				Cars
			</h1>
		</div>
		<p class="applet">
			<applet code="PanelApplet.class" width=1000 height=700></applet>
		</p>
		<div class="box">
			<p class="text">
				This is a simulator for digital braitenburg vehicles. However, I do not feel
				like describing it much more...
			</p>
		</div>
	</body>
</html>
